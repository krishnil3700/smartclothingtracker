from flask import Flask, render_template, jsonify
import requests
from collections import Counter

app = Flask(__name__)

# Fetch data from ThingSpeak for all 8 fields
def fetch_thingspeak_data(channel_id, read_api_key, results=10):
    url = f"https://api.thingspeak.com/channels/{channel_id}/feeds.json?api_key={read_api_key}&results={results}"
    response = requests.get(url)
    data = response.json()
    feeds = data.get('feeds', [])
    return feeds

# Process clothing data and all other fields (e.g., field1 to field8)
def process_clothing_data(feeds):
    clothing_types = [feed['field1'] for feed in feeds if feed['field1']]
    clothing_counter = Counter(clothing_types)
    most_worn = clothing_counter.most_common(1)[0][0] if clothing_counter else "No data"

    # Fetch additional data from fields
    brand_names = [feed['field2'] for feed in feeds if feed['field2']]  # Clothing brand
    clothing_descriptions = [feed['field3'] for feed in feeds if feed['field3']]  # Clothing description/type
    wardrobe_temperature = [feed['field7'] for feed in feeds if feed['field7']]
    wardrobe_humidity = [feed['field8'] for feed in feeds if feed['field8']]

    # Determine most worn brand
    brand_counter = Counter(brand_names)
    most_worn_brand = brand_counter.most_common(1)[0][0] if brand_counter else "No brand data"

    # Least worn clothing
    least_worn = clothing_counter.most_common()[-1][0] if clothing_counter else "No data"

    # Last clothing item added
    last_item = feeds[-1] if feeds else {}

    # Wardrobe items for inventory
    wardrobe_items = [
        {"brand": feed['field2'], "description": feed['field3'], "last_worn": feed['created_at']}
        for feed in feeds if feed['field2'] and feed['field3']
    ]

    return {
        "clothing_counts": clothing_counter,
        "most_worn": most_worn,
        "most_worn_brand": most_worn_brand,
        "least_worn": least_worn,
        "brand_names": brand_names,
        "clothing_descriptions": clothing_descriptions,
        "wardrobe_temperature": wardrobe_temperature,
        "wardrobe_humidity": wardrobe_humidity,
        "last_item": last_item,
        "wardrobe_items": wardrobe_items
    }

# Outfit matching logic
def recommend_outfits(wardrobe_items):
    tops = [item for item in wardrobe_items if 'shirt' in item['description'].lower() or 'top' in item['description'].lower()]
    bottoms = [item for item in wardrobe_items if 'pants' in item['description'].lower() or 'jeans' in item['description'].lower()]
    
    # Simple recommendation: match tops and bottoms
    if tops and bottoms:
        return f"Try pairing your {tops[0]['description']} from {tops[0]['brand']} with your {bottoms[0]['description']} from {bottoms[0]['brand']}."
    return "Not enough items to recommend an outfit."

# Get donation/recycling centers
def get_donation_centers():
    return [
        {"name": "Clothing Donation Center 1", "address": "123 Street, Auckland"},
        {"name": "Clothing Donation Center 2", "address": "456 Road, Auckland"}
    ]

# Get creative clothing ideas
def get_creative_clothing_ideas():
    return [
        "Turn an old T-shirt into a tote bag.",
        "Repurpose jeans into denim coasters.",
        "Create a patchwork blanket using old shirts."
    ]

# Route to fetch clothing and field data insights
@app.route('/insights')
def get_clothing_insights():
    # Fetch ThingSpeak data for clothing tracking and other fields
    channel_id = "2661669"  # Replace with your channel ID
    read_api_key = "0TVQRHJWDP1GBP3Y"  # Replace with your read API key
    feeds = fetch_thingspeak_data(channel_id, read_api_key)
    clothing_data = process_clothing_data(feeds)

    # Get outfit recommendations
    outfit_recommendation = recommend_outfits(clothing_data['wardrobe_items'])

    return jsonify({
        "clothing_data": clothing_data,
        "outfit_recommendation": outfit_recommendation,
        "donation_centers": get_donation_centers(),
        "creative_ideas": get_creative_clothing_ideas()
    })

# Main route to render the insights page (landing page)
@app.route('/')
def index():
    return render_template('insights.html')

# Route for wardrobe inventory page
@app.route('/inventory')
def inventory():
    return render_template('inventory.html')

# Route for outfit matching page
@app.route('/outfit-matching')
def outfit_matching():
    return render_template('outfit_matching.html')

# Route for clothing donation page
@app.route('/donation')
def donation():
    return render_template('donation.html')

# Route for creative ideas page
@app.route('/creative-ideas')
def creative_ideas():
    return render_template('creative_ideas.html')

if __name__ == "__main__":
    app.run(debug=True)
